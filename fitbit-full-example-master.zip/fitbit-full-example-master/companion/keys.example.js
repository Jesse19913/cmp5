export const API_KEY = 'hier moet uw api key voor mapbox';
