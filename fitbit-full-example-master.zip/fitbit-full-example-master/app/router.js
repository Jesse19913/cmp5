import * as index from './pages/index';
import * as detail from './pages/detail';
import * as replace from './pages/replace';

export default {
  index,
  detail,
  replace,
};
